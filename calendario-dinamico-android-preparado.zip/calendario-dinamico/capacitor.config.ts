import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.calendariodinamico.app',
  appName: 'CALENDARIO DINAMICO',
  webDir: 'www'
};

export default config;
