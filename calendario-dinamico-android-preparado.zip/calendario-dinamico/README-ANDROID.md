# CALENDARIO DINAMICO — Android

Este proyecto contiene la versión web y el proyecto Android generado con Capacitor.

## Estructura

- `www/` — aplicación HTML/CSS/JavaScript.
- `android/` — proyecto Android de Capacitor.
- `capacitor.config.ts` — configuración de la aplicación.

## Datos actuales

- Nombre: CALENDARIO DINAMICO
- App ID: `com.calendariodinamico.app`
- Versión: `1.0` / versionCode `1`
- minSdk: 24
- targetSdk: 36
- compileSdk: 36

La aplicación utiliza `localStorage` para conservar datos y configuraciones del usuario.

## En Windows

Requisitos:

1. Node.js 22 o superior.
2. Android Studio con Android SDK instalado.
3. Java 21 (JDK 21).

Desde la carpeta raíz:

```bat
npm install
npx cap sync android
```

Para abrir Android Studio:

```bat
npx cap open android
```

Para generar APK de depuración desde una terminal de Windows:

```bat
cd android
gradlew.bat assembleDebug
```

El APK quedará normalmente en:

`android\app\build\outputs\apk\debug\app-debug.apk`

## Importante

Si se modifica `www/index.html`, antes de compilar Android ejecutar:

```bat
npx cap sync android
```

No se debe editar manualmente `android/app/src/main/assets/public/index.html`; Capacitor lo actualiza desde `www/` durante la sincronización.
